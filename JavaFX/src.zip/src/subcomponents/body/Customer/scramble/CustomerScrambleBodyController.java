package subcomponents.body.Customer.scramble;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import utills.Engine;

import java.util.List;

public class CustomerScrambleBodyController {
    Engine engine=Engine.getInstance();

    List<String> allCategoriesList;

    List<String> choosenCategories;
    @FXML
    private Button activateScrambleButton;

    @FXML
    private Label amountToInvestLabel;

    @FXML
    private TextField amountToInvestTextField;

    @FXML
    private ListView<String> categoriesOptionsListView;

    @FXML
    private Button forwardCategoriesButton;

    @FXML
    private Label maxOpenLoansLabel;

    @FXML
    private TextField maxOpenLoansTextField;

    @FXML
    private Label maxOwnershipLabel;

    @FXML
    private TextField maxOwnershipTextField;

    @FXML
    private Label minInterestLabel;

    @FXML
    private Label minYazLabel;

    @FXML
    private TextField minimumInterestTextField;

    @FXML
    private TextField minimumYazTextField;

    @FXML
    private Button showRelevantLoansListButton;

    @FXML
    private ListView<String> userChoiceCategoriesListView;

    @FXML
    void activateActivateScrambleButton(ActionEvent event) {
        int amount=Integer.parseInt(amountToInvestTextField.getText());
        int minInterest = Integer.parseInt(minimumInterestTextField.getText());
        int minYaz = Integer.parseInt(minimumYazTextField.getText());
        int maxOpenLoans = Integer.parseInt(maxOpenLoansTextField.getText());
        int maxOwnership = Integer.parseInt(maxOwnershipTextField.getText());
    }


    @FXML
    void activateForwardCategoriesButton(ActionEvent event) {
        choosenCategories = categoriesOptionsListView.getSelectionModel().getSelectedItems();
        userChoiceCategoriesListView.getItems().addAll(choosenCategories);
    }

    @FXML
    void activateMinimumInterestTextField(ActionEvent event) {

    }


    @FXML
    void activateShowRelevantLoansListButton(ActionEvent event) {

    }



    public void initialize(){
        allCategoriesList = engine.getDatabase().getAllCategories();
        categoriesOptionsListView.getItems().addAll(allCategoriesList);
    }

}
