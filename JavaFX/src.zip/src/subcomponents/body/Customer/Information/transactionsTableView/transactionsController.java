package subcomponents.body.Customer.Information.transactionsTableView;

import Money.operations.Transaction;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import subcomponents.body.Customer.Information.CustomerInformationBodyCont;
import utills.Engine;

public class transactionsController {
    Engine engine = Engine.getInstance();
    private CustomerInformationBodyCont customerInformationBodyCont;


    @FXML
    private TextField amountTextField;

    @FXML
    private Button chargeButton;



    @FXML
    private Button withdrawButton;


    @FXML
    void activateAmountTextField(ActionEvent event) {

    }

    @FXML
    void activateChargeButton(ActionEvent event) {
        int amount=Integer.parseInt(amountTextField.getText());
        customerInformationBodyCont.createTransaction(amount);
        loadTableData();
    }

    @FXML
    void activateWithdrawButton(ActionEvent event) {
        int amount=Integer.parseInt(amountTextField.getText());
        customerInformationBodyCont.createTransaction(amount);
        loadTableData();
    }


    @FXML
    private TableColumn<Transaction, Integer> amount;

    @FXML
    private TableColumn<Transaction, Integer> postBalance;

    @FXML
    private TableColumn<Transaction, Integer> preBalance;

    @FXML
    private TableView<Transaction> transactionsTableView;

    @FXML
    private TableColumn<Transaction, Integer> yaz;

    ObservableList<Transaction> transactionsObservableList = FXCollections.observableArrayList();;

    public void setMainController(CustomerInformationBodyCont customerInformationBodyCont) {
        this.customerInformationBodyCont = customerInformationBodyCont;
    }

    public void initialize(){
        amount.setCellValueFactory(new PropertyValueFactory<Transaction, Integer>("sum"));
        postBalance.setCellValueFactory(new PropertyValueFactory<Transaction, Integer>("balanceAfter"));
        preBalance.setCellValueFactory(new PropertyValueFactory<Transaction, Integer>("balanceBefore"));
        yaz.setCellValueFactory(new PropertyValueFactory<Transaction, Integer>("timeOfMovement"));
    }



    public void loadTableData(){
        String customerName=customerInformationBodyCont.customerNameProperty().get();
        transactionsObservableList =engine.getClientTransactionsList(customerName);

        transactionsTableView.setItems(transactionsObservableList);
        //todo:take the name of the customer from the main controller and pass
    }
}
